#! /bin/bash

ANIO=$1

[ -z "$ANIO" ] && ANIO=$(date +'%Y')

tercer_lunes() {

MES=$1

for D in 01 02 03 04 05 06 07 08; do
	[ "$(date --date "$ANIO-$MES-$D" +'%w')" -eq 1 ] && DIA="$ANIO-$MES-$D" 
done

FECHA=$(date --date "$DIA 14 days" +'%d/%m/%Y')



}


tercer_lunes 06

echo "Paso a la inmortalidad de belgrano;$FTL"


echo "---------------------------------------------------------------"

tercer_lunes 08

echo "Paso a la inmortalidad de san martin;$FTL"
	
