#! /bin/bash
DATE=$1
ANIO=$(date --date $DATE +%Y)

tercer_lunes_junio() {
	MES=$1
	for D in 01 02 03 04 05 06; do
		[ "$(date --date "$ANIO-$MES-$D" +'%w')" -eq 1 ] && DIA="$ANIO-$MES-$D" 
	done
	FTL=$(date --date "$DIA 14 days" +%m%d)
	
}


tercer_lunes_agosto() {
	MES=$1
	for D in 01 02 03 04 05 06 07 08; do
		[ "$(date --date "$ANIO-$MES-$D" +'%w')" -eq 1 ] && DIA="$ANIO-$MES-$D" 
	done
	FTL2=$(date --date "$DIA 14 days" +%m%d)
	return $FTL
	}

function calcular_dia_de_la_raza {
	MES=$1
	DOW="$(date --date "$ANIO-$MES-12" +%w)"
	DIA2="12/$MES/$ANIO"
		if [ $DOW -eq 2 ] || [ $DOW -eq 3 ]; then
		for D in 12 11 10; do
			[ "$(date --date "$ANIO-$MES-$D" +%w)" -eq 1 ] && DIA2="$ANIO-$MES-$D"
		done
		fi
		if [ $DOW -eq 4 ] || [ $DOW -eq 5 ];then
			for D in 12 13 14 15 16; do
				[ "$(date --date "$ANIO-$MES-$D" +%w)" ] && DIA2="$ANIO-$MES-$D"
			done
		fi
	FDR=$(date --date "$DIA2" +%m%d)
}



esLaborable() {
# en las primeras 3 lineas buscamos pasara la fecha como parametro y luego en l segunda hacemos que nos devuelva el dia de la semana ( 1 a 5 dia de semana, y 0 y 6 es fin de semana y en la tercera linea hacemos que nos devuelva la fecha en mmdd para saber si es un feriado y luego los comparamos mas abajo en los elif y si es el else evalua el numero del dia de la semana		

	



	ANIO=$(date --date $DATE +%Y)
	DATE=$1
	DIA_SEMANA=$(date --date $DATE +%w)
	FECHA_FERIADO=$(date --date $DATE  +%m%d)
	MES=$(date --date $DATE +%m)


	tercer_lunes_junio 06
	tercer_lunes_agosto 08
	calcular_dia_de_la_raza 10
	

	if [ $FTL -eq $FECHA_FERIADO ]; then
	echo "Paso a la inmortalidad de belgrano"
	elif [ $FTL2 -eq $FECHA_FERIADO ];then
	echo "Paso a la inmortalidad de san martin"

	elif [ $FDR -eq $FECHA_FERIADO ];then
	echo "DIA DE LA RAZA" 
 
	elif
	[ $FECHA_FERIADO -eq "0101" ];
	then
	echo "es un dia no laborable por que es año nuevo" 
	elif
	[ $FECHA_FERIADO -eq "0324" ];then
	echo "es un dia no laborable por que es el dia de la memoria"
	elif
 	[ $FECHA_FERIADO -eq 0402 ];then
	echo "es un dia no laborable por que el dia de los veteranos y caidos e malvinas"

	elif [ $FECHA_FERIADO -eq 0501 ];then
	echo "es un dia no laborable por que es el dia del trabajo"
	
 	elif [ $FECHA_FERIADO -eq 0525 ]; then
	echo "es un dia no laborable por que es el aniversario de la revolucion de mayo"

 	elif [ $FECHA_FERIADO -eq 0709 ]; then
	echo "es un dia no laborable por que es el dia de la independencia" 
	 
	elif [ $FECHA_FERIADO -eq 1120 ]; then
	echo "dia no laborable por el dia de la soberania nacional"

 	elif [ $FECHA_FERIADO -eq 1208 ]; then
	echo "es un dia no laborable por que es el dia de la inmaculada concepcion de maria"

	elif [ $FECHA_FERIADO -eq 1225 ];
	then
	echo "es un dia no laborable por navidad"
	

	else
		if [ $DIA_SEMANA -eq "1" ] || [ $DIA_SEMANA -eq "2" ] || [ $DIA_SEMANA -eq "3" ] || [ $DIA_SEMANA -eq "4" ] || [ $DIA_SEMANA -eq "5" ];
		then	
			echo "es un dia laborable"
		else
			echo "es un dia no laborable"
		fi
	fi
	
}
