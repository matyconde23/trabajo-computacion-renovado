#! /bin/bash

# la funcion mylog es la que se encarga de mandar el mail si es que salio bien o mal, con el horario de cuando se hizo
function mylog {
	TEXTO=$1
	FECHA_HORA=$(date +'%H:%M:%S')
	ls | mailx -s "($FECHA_HORA - $TEXTO)" /var/mail/root
}
# en el if con el -d vemos si el directorio que le pasemos como parametro existe el primer parametro es el directorio a backapear y el segundo parametro osea $3 es donde se va a guardar

#verifico que si MONTADO me da mayor a 0 el directorio pasado por parametro esta montado


MONTADO=0
for i in $(cat /etc/fstab | grep $2);do
let MONTADO++
done
echo $MONTADO


DIRECTORIO=$(pwd)
ORIGEN=$1
NAMEBACKUP=${ORIGEN///}_bkp_$(date +%Y%m%d).tar.gz

if [ -d "$1" ] && [ -d "$2" ] && [ $MONTADO -gt 0 ]
then
#Aqui adentro primero hago el tar que hace el backup pero lo hace en el directorio que estamos ejecutando el script entoces le redirigo al directorio pasado como parametro que seria u03 y luego lo borro de el directorio donde se guardo por primera vez
	
	tar cpzf $NAMEBACKUP $ORIGEN
	cat $ORIGEN/$NAMEBAUCKP >> $2/$NAMEBACKUP
	rm $DIRECTORIO/$NAMEBACKUP
	mylog "haciendo backup del directorio $1"
else	
	mylog "no se pudo hacer el backup del directorio $1"
fi

