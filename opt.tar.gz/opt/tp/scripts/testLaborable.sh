#! /bin/bash

#aqui voy a buscar la funcion y luego me la guardo en una variable para pasarle el parametro y luego imprimo el mensaje
source "/opt/tp/scripts/esLaborable.sh"
resultado=$(esLaborable $1)
echo "$resultado"
